package sample;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;

import javax.swing.*;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import java.util.StringTokenizer;

public class Controller implements Initializable {



    //required variables
    String patientName;
    String patientGender;
    String patientPhone;
    String patientEmail;
    String patientDOB;
    int calculatedDOB=2021;
    String PatientInsurance;
    String patientNationality;
    int fileNO;
    int patientAge;
    String patientID;
    int fid;
    String search;
    int total=0;
    String procedure="";


    @FXML
    TableView myTable=new TableView();

    // text fields for patients tab
    @FXML
    TextField nameField,phoneNoField,emailField,fileNoField,idField,nationalityField,searchField;

    //buttons for patients tab
    @FXML
    Button addPatientButton,deleteButton,searchButton,editPatientButton;

    //combo box for patients tab
    @FXML
    private ComboBox<String> comboBox,monthBox,yearBox,insuranceBox;

    @FXML
    CheckBox maleBox,femaleBox;

    // giving columns of table a name
    @FXML
    TableColumn nameColumn=new TableColumn("Name");

    @FXML
    TableColumn fileNoColumn=new TableColumn("File No");

    @FXML
    TableColumn ageColumn=new TableColumn("Age");

    @FXML
    TableColumn phoneColumn=new TableColumn("Phone");


    //visits tab data


    @FXML
    TextField visitPatientNameField,visitPatientNameIDField;

    @FXML
    TableView myVisitsTable=new TableView();


    @FXML
    Button addVisitButton,deleteVisitButton,editVisitButton,saveToFileVisitButton;

    @FXML
    private CheckBox generalExaminationBox,xRayBox,compositeFillingBox,rootCanalBox,extractionBox,whiteningBox,porcelainBox,removalBracesBox,dentalImplantBox;

    @FXML
    private ComboBox<String> visitDayBox,visitMonthBox,visitYearBox;

    @FXML
    TableColumn visitDateColumn=new TableColumn("Visit Date");

    @FXML
    TableColumn visitProceduresColumn=new TableColumn("Procedures");

    @FXML
    TableColumn visitTotalColumn=new TableColumn("Total");


    // Reports tab data

    @FXML
    private ComboBox<String> fromReportMonthBox,fromReportYearBox,toReportMonthBox,toReportYearBox;
    @FXML
    private CheckBox displayRevenueCheckBox,displayAllTreatmentsCheckBox;
    @FXML
    Button saveReportToFileButton,saveAllPatientsToFile;

    String totalPProcedures="";
    int revenue=0;

    ArrayList<String> list=new ArrayList<>();

    //array list to store patients data
    ArrayList<Patient> patients=new ArrayList<>();

    ArrayList<Visits> selectedVisits=new ArrayList<>();

    ArrayList<PatientRecords> pRecords=new ArrayList<>();

    //observable list to add data to table columns
    final ObservableList<Patient> data=FXCollections.observableArrayList();
    final ObservableList<Visits> visitData=FXCollections.observableArrayList();
    ArrayList<Visits> visits=new ArrayList<>();

    Patient p=new Patient(null,null,null,null,null,null,null,0,0,null);
    Visits v=new Visits(null,null,0,0,null);


//initialize method
    @Override
    public void initialize(URL location, ResourceBundle resources) {

        //Patient tab code starts from here

        myTable.setEditable(true);
        fileNoField.setEditable(false);
        //setting day/date/month to combo boxes
        comboBox.setItems(FXCollections.observableArrayList("1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19","20","21","22","23","24","25","26","27","28","29","30"));
        monthBox.setItems(FXCollections.observableArrayList("January","February","March","April","May","June","July","August","September","October","November","December"));

        for (int i=1920;i<2022;i++){
            String s= String.valueOf(i);
            list.add(s);
        }
        yearBox.setItems(FXCollections.observableArrayList(list));
        insuranceBox.setItems(FXCollections.observableArrayList("THIQA","ABCD"));

        //calculatedDOB=calculatedDOB-Integer.parseInt(patientDOB);
        //patientID= Integer.parseInt(idField.getText());
        //fileNO= Integer.parseInt(fileNoField.getText());


        myTable.getColumns().addAll(nameColumn,fileNoColumn,ageColumn,phoneColumn);

        //setting columns values to a variable
        nameColumn.setCellValueFactory(new PropertyValueFactory<Patient,String>("name"));
        fileNoColumn.setCellValueFactory(new PropertyValueFactory<Patient, Integer>("file"));
        ageColumn.setCellValueFactory(new PropertyValueFactory<Patient,Integer>("age"));
        phoneColumn.setCellValueFactory(new PropertyValueFactory<Patient,String>("phone"));


        //Patient tab code ends from here


        //visit tab starts here

        // same stuff like patients tab for this section too
        myVisitsTable.setEditable(true);
        visitPatientNameIDField.setEditable(false);
        visitDayBox.setItems(FXCollections.observableArrayList("1","2","3","4","5","6","7","8","9","10","11","12","13","14","15","16","17","18","19","20","21","22","23","24","25","26","27","28","29","30"));
        visitMonthBox.setItems(FXCollections.observableArrayList("January","February","March","April","May","June","July","August","September","October","November","December"));


        visitYearBox.setItems(FXCollections.observableArrayList(list));
        myVisitsTable.getColumns().addAll(visitDateColumn,visitProceduresColumn,visitDateColumn);

        visitDateColumn.setCellValueFactory(new PropertyValueFactory<Patient,String>("vDate"));
        visitProceduresColumn.setCellValueFactory(new PropertyValueFactory<Patient, Integer>("vProcedures"));
        visitTotalColumn.setCellValueFactory(new PropertyValueFactory<Patient,String>("vTotal"));

        //visit tab ends here

        //reports tab starts here
        fromReportMonthBox.setItems(FXCollections.observableArrayList("January","February","March","April","May","June","July","August","September","October","November","December"));


        fromReportYearBox.setItems(FXCollections.observableArrayList(list));

        toReportMonthBox.setItems(FXCollections.observableArrayList("January","February","March","April","May","June","July","August","September","October","November","December"));


        toReportYearBox.setItems(FXCollections.observableArrayList(list));

        //reports tab ends here

    }
//Button actions

    //add patient button
    public void onPressAddPatient() throws Exception{



        if (nameField.getText().trim().isEmpty()){
            Dialog<String> dialog=new Dialog<String>();
            dialog.setTitle("Blank Field!");
            dialog.setContentText("Fill Patient's name");
            ButtonType type=new ButtonType("Ok", ButtonBar.ButtonData.OK_DONE);
            dialog.getDialogPane().getButtonTypes().add(type);
            dialog.showAndWait();
        }
        else if (phoneNoField.getText().trim().isEmpty()){
            Dialog<String> dialog=new Dialog<String>();
            dialog.setTitle("Blank Field!");
            dialog.setContentText("Fill Patient's phone");
            ButtonType type=new ButtonType("Ok", ButtonBar.ButtonData.OK_DONE);
            dialog.getDialogPane().getButtonTypes().add(type);
            dialog.showAndWait();
        }
        else if (emailField.getText().trim().isEmpty()){
            Dialog<String> dialog=new Dialog<String>();
            dialog.setTitle("Blank Field!");
            dialog.setContentText("Fill Patient's Email");
            ButtonType type=new ButtonType("Ok", ButtonBar.ButtonData.OK_DONE);
            dialog.getDialogPane().getButtonTypes().add(type);
            dialog.showAndWait();
        }
        else if (idField.getText().trim().isEmpty()){
            Dialog<String> dialog=new Dialog<String>();
            dialog.setTitle("Blank Field!");
            dialog.setContentText("Fill patient's ID");
            ButtonType type=new ButtonType("Ok", ButtonBar.ButtonData.OK_DONE);
            dialog.getDialogPane().getButtonTypes().add(type);
            dialog.showAndWait();
        }
        else if (nationalityField.getText().trim().isEmpty()){
            Dialog<String> dialog=new Dialog<String>();
            dialog.setTitle("Blank Field!");
            dialog.setContentText("Fill Patient's Nationality");
            ButtonType type=new ButtonType("Ok", ButtonBar.ButtonData.OK_DONE);
            dialog.getDialogPane().getButtonTypes().add(type);
            dialog.showAndWait();
        }
        else {
        Integer age=0;
        String ageString="";
        //calculating age of patient by getting value from year box and subtracting current year from it
        try{
            age = 2021- Integer.valueOf(Integer.parseInt(yearBox.getValue()));
            ageString= String.valueOf(age);
        }
        catch (NumberFormatException ex){
            ex.printStackTrace();
        }

        fid++;
        patientName=nameField.getText();
        patientPhone=phoneNoField.getText();
        patientEmail=emailField.getText();
        patientDOB=comboBox.getValue()+"/"+monthBox.getValue()+"/"+yearBox.getValue();
        patientNationality=nationalityField.getText();
        PatientInsurance=insuranceBox.getValue();
        patientID=idField.getText();
        patientAge=20;
        fileNoField.setText(String.valueOf(fid));


        p.addPatient(patients,patientName,patientGender,patientPhone,patientEmail,patientDOB,PatientInsurance,patientNationality,fid,age,patientID);
        System.out.println(patients);



        data.add(new Patient(patientName,String.valueOf(fid),ageString,patientPhone));

        Dialog<String> dialog=new Dialog<String>();
        dialog.setTitle("Message!");
        dialog.setContentText("Data Entered Successfully!");
        ButtonType type=new ButtonType("Ok", ButtonBar.ButtonData.OK_DONE);
        dialog.getDialogPane().getButtonTypes().add(type);
        dialog.showAndWait();

        myTable.setEditable(true);
        myTable.setItems(data);
        }
        nameField.clear();
        phoneNoField.clear();
        emailField.clear();
        comboBox.setValue(null);
        monthBox.setValue(null);
        yearBox.setValue(null);
        insuranceBox.setValue(null);
        fileNoField.clear();
        idField.clear();
        nationalityField.clear();
    }

    //add patient visit button
    public void onPressAddVisitButton() throws Exception{



        if (visitPatientNameField.getText().trim().isEmpty()){
            Dialog<String> dialog=new Dialog<String>();
            dialog.setTitle("Blank Field!");
            dialog.setContentText("Fill Patient's name");
            ButtonType type=new ButtonType("Ok", ButtonBar.ButtonData.OK_DONE);
            dialog.getDialogPane().getButtonTypes().add(type);
            dialog.showAndWait();
        }
        else{

            String ageString="";
            //calculating age of patient by getting value from year box and subtracting current year from it
            try{
                total = 2021- Integer.valueOf(Integer.parseInt(yearBox.getValue()));
                ageString= String.valueOf(total);
            }
            catch (NumberFormatException ex){
                ex.printStackTrace();
            }

            String patientTotal;
            patientName=visitPatientNameField.getText();
            patientDOB=visitDayBox.getValue()+"/"+visitMonthBox.getValue()+"/"+visitYearBox.getValue();
            visitPatientNameIDField.setText(String.valueOf(fid));
            patientTotal= String.valueOf(total);

            v.addVisit(visits,patientDOB,patientName,fid,total,procedure);
            System.out.println(visits);

            for (int i=0;i<visits.size();i++){
                revenue=revenue+visits.get(i).getVisitTotal();
            }
            System.out.println("revenue "+revenue);

            visitData.add(new Visits(patientDOB,procedure,patientTotal));

            Dialog<String> dialog=new Dialog<String>();
            dialog.setTitle("Message!");
            dialog.setContentText("Visit Data Entered Successfully!");
            ButtonType type=new ButtonType("Ok", ButtonBar.ButtonData.OK_DONE);
            dialog.getDialogPane().getButtonTypes().add(type);
            dialog.showAndWait();

            myVisitsTable.setEditable(true);
            myVisitsTable.setItems(visitData);

            visitPatientNameIDField.clear();
            visitPatientNameField.clear();
            emailField.clear();
            visitDayBox.setValue(null);
            visitMonthBox.setValue(null);
            visitYearBox.setValue(null);
            generalExaminationBox.setSelected(false);
            rootCanalBox.setSelected(false);
            removalBracesBox.setSelected(false);
            porcelainBox.setSelected(false);
            extractionBox.setSelected(false);
            whiteningBox.setSelected(false);
            xRayBox.setSelected(false);
            dentalImplantBox.setSelected(false);
            compositeFillingBox.setSelected(false);

          total=0;
          revenue=0;
        }
    }

    public void maleCheckBoxHit(javafx.event.ActionEvent actionEvent){
        if (maleBox.isSelected()){
            patientGender="Male";

        }
    }

    public void femaleCheckBoxHit(javafx.event.ActionEvent actionEvent){
        if (femaleBox.isSelected()){
            patientGender="Female";
        }
    }

    public void geCheckBoxHit(javafx.event.ActionEvent actionEvent){
        if (generalExaminationBox.isSelected()){
            total=total+100;
            procedure=procedure+"General Examination,";
        }
    }

    public void xrayCheckBoxHit(javafx.event.ActionEvent actionEvent){
        if (xRayBox.isSelected()){
            total=total+150;
            procedure=procedure+"X Ray,";
        }
    }

    public void compositeCheckBoxHit(javafx.event.ActionEvent actionEvent){
        if (compositeFillingBox.isSelected()){
            total=total+250;
            procedure=procedure+"Composite Filling,";
        }
    }

    public void rootCheckBoxHit(javafx.event.ActionEvent actionEvent){
        if (rootCanalBox.isSelected()){
            total=total+600;
            procedure=procedure+"Root Canal,";
        }
    }

    public void extractionBoxHIt(javafx.event.ActionEvent actionEvent){
        if (extractionBox.isSelected()){
            total=total+250;
            procedure=procedure+"Extraction,";
        }
    }

    public void whiteningCheckBoxHit(javafx.event.ActionEvent actionEvent){
        if (whiteningBox.isSelected()){
            total=total+1200;
            procedure=procedure+"Whitening,";
        }
    }

    public void porcelainCheckBoxHit(javafx.event.ActionEvent actionEvent){
        if (porcelainBox.isSelected()){
            total=total+1000;
            procedure=procedure+"Porcelain Crown,";
        }
    }

    public void remoavalbracesCheckBoxHit(javafx.event.ActionEvent actionEvent){
        if (removalBracesBox.isSelected()){
            total=total+500;
            procedure=procedure+"Removal Braces,";
        }
    }

    public void dentailimplantCheckBoxHit(javafx.event.ActionEvent actionEvent){
        if (dentalImplantBox.isSelected()){
            total=total+2000;
            procedure=procedure+"Dental Implant";
            System.out.println(total);
            System.out.println(procedure);

        }
    }

    public void displayRevenueCheckBoxHit(javafx.event.ActionEvent actionEvent){
        for (int i=0;i<visits.size();i++){
            revenue=revenue+visits.get(i).getVisitTotal();
        }
        Dialog<String> dialog=new Dialog<String>();
        dialog.setTitle("Revenue!");
        dialog.setContentText("Revenue earned "+revenue);
        ButtonType type=new ButtonType("Ok", ButtonBar.ButtonData.OK_DONE);
        dialog.getDialogPane().getButtonTypes().add(type);
        dialog.showAndWait();
        displayRevenueCheckBox.setSelected(false);
        revenue=0;
    }

    public void displayAllTreatmentsCheckBoxHit(javafx.event.ActionEvent actionEvent){
        for (int i=0;i<visits.size();i++){
            totalPProcedures=totalPProcedures+visits.get(i).getVisitProcedures();
        }
        Dialog<String> dialog=new Dialog<String>();
        dialog.setTitle("Total Procedures Done!");
        dialog.setContentText(totalPProcedures);
        ButtonType type=new ButtonType("Ok", ButtonBar.ButtonData.OK_DONE);
        dialog.getDialogPane().getButtonTypes().add(type);
        dialog.showAndWait();
        displayAllTreatmentsCheckBox.setSelected(false);
        totalPProcedures=null;
    }




    public void deleteButtonPressed(){
        myTable.getItems().remove(myTable.getSelectionModel().getSelectedItem());

        Dialog<String> dialog=new Dialog<String>();
        dialog.setTitle("Message!");
        dialog.setContentText("Data Deleted Successfully!");
        ButtonType type=new ButtonType("Ok", ButtonBar.ButtonData.OK_DONE);
        dialog.getDialogPane().getButtonTypes().add(type);
        dialog.showAndWait();
    }
    public void deleteVisitButtonPressed(){
        myVisitsTable.getItems().remove(myVisitsTable.getSelectionModel().getSelectedItem());
        Dialog<String> dialog=new Dialog<String>();
        dialog.setTitle("Message!");
        dialog.setContentText("Data Deleted Successfully!");
        ButtonType type=new ButtonType("Ok", ButtonBar.ButtonData.OK_DONE);
        dialog.getDialogPane().getButtonTypes().add(type);
        dialog.showAndWait();
    }
    public void saveToFileButton(){
        try {
            FileWriter myWriter = new FileWriter("Visits.txt");
            myWriter.write(visits.toString());

            myWriter.close();
            System.out.println("Successfully wrote to the file.");
        } catch (IOException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
        Dialog<String> dialog=new Dialog<String>();
        dialog.setTitle("Success!");
        dialog.setContentText("Successfully wrote all patients details to file!");
        ButtonType type=new ButtonType("Ok", ButtonBar.ButtonData.OK_DONE);
        dialog.getDialogPane().getButtonTypes().add(type);
        dialog.showAndWait();
    }
    public void saveSelectedVisitsToFileButton(){
        try {
            FileWriter myWriter = new FileWriter("Visits.txt");
            myWriter.write(visits.toString());


            myWriter.close();
            System.out.println("Successfully wrote to the file.");
        } catch (IOException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
        Dialog<String> dialog=new Dialog<String>();
        dialog.setTitle("Success!");
        dialog.setContentText("Successfully saved visits to file!");
        ButtonType type=new ButtonType("Ok", ButtonBar.ButtonData.OK_DONE);
        dialog.getDialogPane().getButtonTypes().add(type);
        dialog.showAndWait();
    }
    public void searchButtonPressed(){

        int flag=0;
        search=searchField.getText();
        for (int i=0;i<patients.size();i++){
            if (patients.get(i).getPatientPhone().equals(search)){
                Dialog<String> dialog=new Dialog<String>();
                dialog.setTitle("Found!");
                dialog.setContentText(String.valueOf(patients.get(i)));
                ButtonType type=new ButtonType("Ok", ButtonBar.ButtonData.OK_DONE);
                dialog.getDialogPane().getButtonTypes().add(type);
                dialog.showAndWait();
                flag=1;
            }
        }
        if (flag==0){
            Dialog<String> dialog=new Dialog<String>();
            dialog.setTitle("Not Found!");
            dialog.setContentText("No such patient found!");
            ButtonType type=new ButtonType("Ok", ButtonBar.ButtonData.OK_DONE);
            dialog.getDialogPane().getButtonTypes().add(type);
            dialog.showAndWait();
        }

    }
    public void getComboBoxInfo1(javafx.event.ActionEvent actionEvent) {
        System.out.println(visitDayBox.getValue());
        System.out.println(visitMonthBox.getValue());
        System.out.println(visitYearBox.getValue());

    }

    public void getComboBoxInfo(javafx.event.ActionEvent actionEvent) {
        System.out.println(comboBox.getValue());
        System.out.println(monthBox.getValue());
        System.out.println(yearBox.getValue());
        System.out.println(insuranceBox.getValue());
        System.out.println(fromReportMonthBox.getValue());
        System.out.println(fromReportYearBox.getValue());
        System.out.println(toReportMonthBox.getValue());
        System.out.println(toReportYearBox.getValue());
    }
public void editPatientButtonPressed(){
    myTable.getItems().remove(myTable.getSelectionModel().getSelectedItem());


    if (nameField.getText().trim().isEmpty()){
        Dialog<String> dialog=new Dialog<String>();
        dialog.setTitle("Blank Field!");
        dialog.setContentText("Fill Patient's name");
        ButtonType type=new ButtonType("Ok", ButtonBar.ButtonData.OK_DONE);
        dialog.getDialogPane().getButtonTypes().add(type);
        dialog.showAndWait();
    }
    else if (phoneNoField.getText().trim().isEmpty()){
        Dialog<String> dialog=new Dialog<String>();
        dialog.setTitle("Blank Field!");
        dialog.setContentText("Fill Patient's phone");
        ButtonType type=new ButtonType("Ok", ButtonBar.ButtonData.OK_DONE);
        dialog.getDialogPane().getButtonTypes().add(type);
        dialog.showAndWait();
    }
    else if (emailField.getText().trim().isEmpty()){
        Dialog<String> dialog=new Dialog<String>();
        dialog.setTitle("Blank Field!");
        dialog.setContentText("Fill Patient's Email");
        ButtonType type=new ButtonType("Ok", ButtonBar.ButtonData.OK_DONE);
        dialog.getDialogPane().getButtonTypes().add(type);
        dialog.showAndWait();
    }
    else if (idField.getText().trim().isEmpty()){
        Dialog<String> dialog=new Dialog<String>();
        dialog.setTitle("Blank Field!");
        dialog.setContentText("Fill patient's ID");
        ButtonType type=new ButtonType("Ok", ButtonBar.ButtonData.OK_DONE);
        dialog.getDialogPane().getButtonTypes().add(type);
        dialog.showAndWait();
    }
    else if (nationalityField.getText().trim().isEmpty()){
        Dialog<String> dialog=new Dialog<String>();
        dialog.setTitle("Blank Field!");
        dialog.setContentText("Fill Patient's Nationality");
        ButtonType type=new ButtonType("Ok", ButtonBar.ButtonData.OK_DONE);
        dialog.getDialogPane().getButtonTypes().add(type);
        dialog.showAndWait();
    }
    else {
        Integer age=0;
        String ageString="";
        //calculating age of patient by getting value from year box and subtracting current year from it
        try{
            age = 2021- Integer.valueOf(Integer.parseInt(yearBox.getValue()));
            ageString= String.valueOf(age);
        }
        catch (NumberFormatException ex){
            ex.printStackTrace();
        }

        fid++;
        patientName=nameField.getText();
        patientPhone=phoneNoField.getText();
        patientEmail=emailField.getText();
        patientDOB=comboBox.getValue()+"/"+monthBox.getValue()+"/"+yearBox.getValue();
        patientNationality=nationalityField.getText();
        PatientInsurance=insuranceBox.getValue();
        patientID=idField.getText();
        patientAge=20;
        fileNoField.setText(String.valueOf(fid));


        p.addPatient(patients,patientName,patientGender,patientPhone,patientEmail,patientDOB,PatientInsurance,patientNationality,fid,age,patientID);
        System.out.println(patients);



        data.add(new Patient(patientName,String.valueOf(fid),ageString,patientPhone));

        Dialog<String> dialog=new Dialog<String>();
        dialog.setTitle("Message!");
        dialog.setContentText("Patient Data Edited Successfully!");
        ButtonType type=new ButtonType("Ok", ButtonBar.ButtonData.OK_DONE);
        dialog.getDialogPane().getButtonTypes().add(type);
        dialog.showAndWait();

        myTable.setEditable(true);
        myTable.setItems(data);
    }
    nameField.clear();
    phoneNoField.clear();
    emailField.clear();
    comboBox.setValue(null);
    monthBox.setValue(null);
    yearBox.setValue(null);
    insuranceBox.setValue(null);
    fileNoField.clear();
    idField.clear();
    nationalityField.clear();

}
public void editVisitButtonPresses(){
    myVisitsTable.getItems().remove(myVisitsTable.getSelectionModel().getSelectedItem());
    if (visitPatientNameField.getText().trim().isEmpty()){
        Dialog<String> dialog=new Dialog<String>();
        dialog.setTitle("Blank Field!");
        dialog.setContentText("Fill Patient's name");
        ButtonType type=new ButtonType("Ok", ButtonBar.ButtonData.OK_DONE);
        dialog.getDialogPane().getButtonTypes().add(type);
        dialog.showAndWait();
    }
    else{

        String ageString="";
        //calculating age of patient by getting value from year box and subtracting current year from it
        try{
            total = 2021- Integer.valueOf(Integer.parseInt(yearBox.getValue()));
            ageString= String.valueOf(total);
        }
        catch (NumberFormatException ex){
            ex.printStackTrace();
        }

        String patientTotal;
        patientName=visitPatientNameField.getText();
        patientDOB=visitDayBox.getValue()+"/"+visitMonthBox.getValue()+"/"+visitYearBox.getValue();
        visitPatientNameIDField.setText(String.valueOf(fid));
        patientTotal= String.valueOf(total);

        v.addVisit(visits,patientDOB,patientName,fid,total,procedure);
        System.out.println(visits);

        for (int i=0;i<visits.size();i++){
            revenue=revenue+visits.get(i).getVisitTotal();
        }
        System.out.println("revenue "+revenue);

        visitData.add(new Visits(patientDOB,procedure,patientTotal));

        Dialog<String> dialog=new Dialog<String>();
        dialog.setTitle("Message!");
        dialog.setContentText("Visit Data Edited Successfully!");
        ButtonType type=new ButtonType("Ok", ButtonBar.ButtonData.OK_DONE);
        dialog.getDialogPane().getButtonTypes().add(type);
        dialog.showAndWait();

        myVisitsTable.setEditable(true);
        myVisitsTable.setItems(visitData);

        visitPatientNameIDField.clear();
        visitPatientNameField.clear();
        emailField.clear();
        visitDayBox.setValue(null);
        visitMonthBox.setValue(null);
        visitYearBox.setValue(null);
        generalExaminationBox.setSelected(false);
        rootCanalBox.setSelected(false);
        removalBracesBox.setSelected(false);
        porcelainBox.setSelected(false);
        extractionBox.setSelected(false);
        whiteningBox.setSelected(false);
        xRayBox.setSelected(false);
        dentalImplantBox.setSelected(false);
        compositeFillingBox.setSelected(false);

        total=0;
        revenue=0;
    }
}

}
