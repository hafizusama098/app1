package sample;

import javafx.beans.property.SimpleStringProperty;

import java.util.ArrayList;

public class Patient {
    private String patientName;
    private String patientGender;
    private String patientPhone;
    private String patientEmail;
    private String patientDOB;
    private String PatientInsurance;
    private String patientNationality;
    private int fileNO;
    private int patientAge;
    private String patientID;

    private SimpleStringProperty name;
    private SimpleStringProperty file;
    private SimpleStringProperty age;
    private SimpleStringProperty phone;

    public Patient(String patientName, String patientGender, String patientPhone, String patientEmail, String patientDOB, String patientInsurance, String patientNationality, int fileNO, int patientAge,String patientID) {
        this.patientName = patientName;
        this.patientGender = patientGender;
        this.patientPhone = patientPhone;
        this.patientEmail = patientEmail;
        this.patientDOB = patientDOB;
        PatientInsurance = patientInsurance;
        this.patientNationality = patientNationality;
        this.fileNO = fileNO;
        this.patientAge = patientAge;
        this.patientID = patientID;
    }

    public Patient( String name, String file, String age, String phone) {
        this.name = new SimpleStringProperty(name);
        this.file = new SimpleStringProperty(file);
        this.age = new SimpleStringProperty(age);
        this.phone = new SimpleStringProperty(phone);
    }



    public void addPatient(ArrayList<Patient> list, String patientName, String patientGender, String patientPhone, String patientEmail, String patientDOB, String patientInsurance, String patientNationality, int fileNO, int patientAge, String patientID){
        list.add(new Patient(patientName,patientGender,patientPhone,patientEmail,patientDOB,patientInsurance,patientNationality,fileNO,patientAge,patientID));
    }

    public void removePatient(ArrayList<Patient> list,String id){
        for (int i=0;i<list.size();i++){
            if (list.get(i).getPatientID().equals(id)){
                list.remove(i);
            }
        }
    }

    public String getName() {
        return name.get();
    }

    public SimpleStringProperty nameProperty() {
        return name;
    }

    public void setName(String name) {
        this.name.set(name);
    }

    public String getFile() {
        return file.get();
    }

    public SimpleStringProperty fileProperty() {
        return file;
    }

    public void setFile(String file) {
        this.file.set(file);
    }

    public String getAge() {
        return age.get();
    }

    public SimpleStringProperty ageProperty() {
        return age;
    }

    public void setAge(String age) {
        this.age.set(age);
    }

    public String getPhone() {
        return phone.get();
    }

    public SimpleStringProperty phoneProperty() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone.set(phone);
    }

    public String getPatientName() {
        return patientName;
    }

    public void setPatientName(String patientName) {
        this.patientName = patientName;
    }

    public String getPatientGender() {
        return patientGender;
    }

    public void setPatientGender(String patientGender) {
        this.patientGender = patientGender;
    }

    public String getPatientPhone() {
        return patientPhone;
    }

    public void setPatientPhone(String patientPhone) {
        this.patientPhone = patientPhone;
    }

    public String getPatientEmail() {
        return patientEmail;
    }

    public void setPatientEmail(String patientEmail) {
        this.patientEmail = patientEmail;
    }

    public String getPatientDOB() {
        return patientDOB;
    }

    public void setPatientDOB(String patientDOB) {
        this.patientDOB = patientDOB;
    }

    public String getPatientInsurance() {
        return PatientInsurance;
    }

    public void setPatientInsurance(String patientInsurance) {
        PatientInsurance = patientInsurance;
    }

    public String getPatientNationality() {
        return patientNationality;
    }

    public void setPatientNationality(String patientNationality) {
        this.patientNationality = patientNationality;
    }

    public int getFileNO() {
        return fileNO;
    }

    public void setFileNO(int fileNO) {
        this.fileNO = fileNO;
    }

    public int getPatientAge() {
        return patientAge;
    }

    public void setPatientAge(int patientAge) {
        this.patientAge = patientAge;
    }

    public String getPatientID() {
        return patientID;
    }

    public void setPatientID(String patientID) {
        this.patientID = patientID;
    }

    @Override
    public String toString() {
        return "\n"+
                "Patient Name: " + patientName + "| " +
                "| Patient Gender: " + patientGender + "| " +
                "| Patient Phone: " + patientPhone + "| " +
                "| patient Email: " + patientEmail + "| " +
                "| patient DOB: " + patientDOB + "| " +
                "| Patient Insurance: '" + PatientInsurance + "| " +
                "| patient Nationality: " + patientNationality + "| " +
                "| fileNO: " + fileNO +"| " +
                "| patient Age: " + patientAge +"| " +
                "| patient ID: " + patientID +
                "\n----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------\n";
    }
}
