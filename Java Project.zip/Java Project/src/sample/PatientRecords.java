package sample;

public class PatientRecords extends Patient{
    private String records;
    public PatientRecords(String patientName, String patientGender, String patientPhone, String patientEmail, String patientDOB, String patientInsurance, String patientNationality, int fileNO, int patientAge, String patientID) {
        super(patientName, patientGender, patientPhone, patientEmail, patientDOB, patientInsurance, patientNationality, fileNO, patientAge, patientID);
    }

    public String getRecords() {
        return records;
    }

    public void setRecords(String records) {
        this.records = records;
    }

    @Override
    public String toString() {
        return "\n"+
                "Patient Name: " + getPatientName() + "| " +
                "| Patient Gender: " + getPatientGender() + "| " +
                "| Patient Phone: " + getPatientPhone() + "| " +
                "| patient Email: " + getPatientEmail() + "| " +
                "| patient DOB: " + getPatientDOB() + "| " +
                "| Patient Insurance: '" + getPatientInsurance() + "| " +
                "| patient Nationality: " + getPatientNationality() + "| " +
                "| fileNO: " + getFileNO() +"| " +
                "| patient Age: " + getPatientAge() +"| " +
                "| patient ID: " + getPatientID() +
                "\n----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------\n";
    }
}

