package sample;

import javafx.beans.property.SimpleStringProperty;

import java.util.ArrayList;

public class Visits {
    private String visitDate;
    private String visitPatientName;
    private int visitPatientFileNo;
    private int visitTotal;
    private String visitProcedures;

    private SimpleStringProperty vDate;
    private SimpleStringProperty vTotal;
    private SimpleStringProperty vProcedures;

    public Visits(String visitDate, String visitPatientName, int visitPatientFileNo, int visitTotal, String visitProcedures) {
        this.visitDate = visitDate;
        this.visitPatientName = visitPatientName;
        this.visitPatientFileNo = visitPatientFileNo;
        this.visitTotal = visitTotal;
        this.visitProcedures = visitProcedures;
    }

    public Visits( String vDate, String vProcedures, String vTotal) {
        this.vDate = new SimpleStringProperty(vDate);
        this.vProcedures = new SimpleStringProperty(vProcedures);
        this.vTotal = new SimpleStringProperty(vTotal);
    }

    public void addVisit(ArrayList<Visits> list, String visitDate, String visitPatientName, int visitPatientFileNo, int visitTotal, String visitProcedures ){
        list.add(new Visits(visitDate,visitPatientName,visitPatientFileNo,visitTotal,visitProcedures));
    }

    public String getVisitDate() {
        return visitDate;
    }

    public void setVisitDate(String visitDate) {
        this.visitDate = visitDate;
    }

    public String getVisitPatientName() {
        return visitPatientName;
    }

    public void setVisitPatientName(String visitPatientName) {
        this.visitPatientName = visitPatientName;
    }

    public int getVisitPatientFileNo() {
        return visitPatientFileNo;
    }

    public void setVisitPatientFileNo(int visitPatientFileNo) {
        this.visitPatientFileNo = visitPatientFileNo;
    }

    public int getVisitTotal() {
        return visitTotal;
    }

    public void setVisitTotal(int visitTotal) {
        this.visitTotal = visitTotal;
    }

    public String getVisitProcedures() {
        return visitProcedures;
    }

    public void setVisitProcedures(String visitProcedures) {
        this.visitProcedures = visitProcedures;
    }

    public String getvDate() {
        return vDate.get();
    }

    public SimpleStringProperty vDateProperty() {
        return vDate;
    }

    public void setvDate(String vDate) {
        this.vDate.set(vDate);
    }

    public String getvTotal() {
        return vTotal.get();
    }

    public SimpleStringProperty vTotalProperty() {
        return vTotal;
    }

    public void setvTotal(String vTotal) {
        this.vTotal.set(vTotal);
    }

    public String getvProcedures() {
        return vProcedures.get();
    }

    public SimpleStringProperty vProceduresProperty() {
        return vProcedures;
    }

    public void setvProcedures(String vProcedures) {
        this.vProcedures.set(vProcedures);
    }

    @Override
    public String toString() {
        return "Visits{" +
                "visit Date='" + visitDate + '\'' +
                ", PatientName='" + visitPatientName + '\'' +
                ", visitPatientFileNo=" + visitPatientFileNo +
                ", Total cost=" + visitTotal +
                ", Procedures='" + visitProcedures + '\'' +
                '}'
                +"\n--------------------------------------------------------------------------------------------------------------------------------------------\n";
    }
}
