package sample;

public class VisitsRecords extends Visits{
    String records;

    public VisitsRecords(String visitDate, String visitPatientName, int visitPatientFileNo, int visitTotal, String visitProcedures) {
        super(visitDate, visitPatientName, visitPatientFileNo, visitTotal, visitProcedures);
    }

    @Override
    public String toString() {
        return "VisitsRecords{" +
                "records='" + records + '\'' +
                '}';
    }
}
